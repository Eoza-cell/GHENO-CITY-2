const { createCanvas } = require('canvas');

async function generateClassSelectionImage() {
    const width = 600;
    const height = 500;
    const canvas = createCanvas(width, height);
    const ctx = canvas.getContext('2d');

    const gradient = ctx.createLinearGradient(0, 0, 0, height);
    gradient.addColorStop(0, '#0a0e27');
    gradient.addColorStop(1, '#1a1f4b');
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, width, height);

    ctx.strokeStyle = '#e94560';
    ctx.lineWidth = 3;
    ctx.strokeRect(15, 15, width - 30, height - 30);

    ctx.fillStyle = '#e94560';
    ctx.font = 'bold 28px serif';
    ctx.textAlign = 'center';
    ctx.fillText('CHOIX DE CLASSE', width / 2, 60);

    ctx.fillStyle = '#aaa';
    ctx.font = '14px sans-serif';
    ctx.fillText('Choisis ta voie dans la matrice d\'Aetherys', width / 2, 90);

    const classes = [
        { name: '⚔️ Guerrier', desc: 'Force brute et endurance' },
        { name: '🔮 Mage', desc: 'Puissance magique dévastatrice' },
        { name: '🗡️ Assassin', desc: 'Vitesse et furtivité' },
        { name: '🏹 Archer', desc: 'Précision à distance' },
        { name: '✨ Prêtre', desc: 'Soins et bénédictions' },
        { name: '👊 Moine', desc: 'Arts martiaux' },
        { name: '🛡️ Paladin', desc: 'Défense et justice' },
        { name: '🌟 Invocateur', desc: 'Invocation de familiers' },
        { name: '💀 Nécromancien', desc: 'Magie des morts' },
        { name: '⚡ Samouraï', desc: 'Lame et honneur' },
        { name: '🐉 Chevalier-Dragon', desc: 'Puissance draconique' },
        { name: '⚗️ Alchimiste', desc: 'Potions et mixtures' },
        { name: '🎵 Barde', desc: 'Musique et soutien' }
    ];

    ctx.font = '14px sans-serif';
    ctx.textAlign = 'left';
    let y = 130;
    for (const cls of classes) {
        ctx.fillStyle = '#e94560';
        ctx.fillText(cls.name, 50, y);
        ctx.fillStyle = '#888';
        ctx.fillText(cls.desc, 200, y);
        y += 25;
    }

    ctx.fillStyle = '#f1c40f';
    ctx.font = 'italic 14px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('Réponds par le nom de ta classe choisie', width / 2, height - 30);

    return canvas.toBuffer('image/png');
}

module.exports = { generateClassSelectionImage };
