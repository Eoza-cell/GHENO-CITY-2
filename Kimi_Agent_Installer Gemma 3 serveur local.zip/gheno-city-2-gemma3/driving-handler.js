/**
 * Driving/Movement handler for GHENO CITY 2
 * Handles travel between locations
 */

const { Player, Kingdom } = require('./database');

const TRAVEL_RATES = {
    walk: { speed: 5, cost: 0 },
    horse: { speed: 20, cost: 0 },
    carriage: { speed: 15, cost: 10 },
    griffin: { speed: 50, cost: 50 },
    dragon: { speed: 80, cost: 200 }
};

/**
 * Calculate travel time between two locations
 */
function calculateTravelTime(from, to, mode = 'walk') {
    const rate = TRAVEL_RATES[mode] || TRAVEL_RATES.walk;
    // Base distance calculation (simplified)
    const baseDistance = 10; // units
    return Math.ceil(baseDistance / rate.speed * 60); // minutes
}

async function travel(player, destination, mode = 'walk') {
    const time = calculateTravelTime(player.location, destination, mode);
    const rate = TRAVEL_RATES[mode];
    
    if (player.col < rate.cost) {
        return { success: false, message: `Pas assez de COL pour ce mode de transport.` };
    }
    
    player.col -= rate.cost;
    await player.save();
    
    return {
        success: true,
        message: `Voyage vers ${destination} en cours... (${time} minutes en ${mode})`,
        duration: time
    };
}

module.exports = {
    calculateTravelTime,
    travel,
    TRAVEL_RATES
};
