const { createCanvas } = require('canvas');

async function generatePaperImage(text, title = "DOCUMENT") {
    const width = 600;
    const height = 800;
    const canvas = createCanvas(width, height);
    const ctx = canvas.getContext('2d');

    // Parchment background
    ctx.fillStyle = '#f5e6c8';
    ctx.fillRect(0, 0, width, height);

    // Aging effect
    ctx.fillStyle = 'rgba(139, 119, 80, 0.1)';
    for (let i = 0; i < 100; i++) {
        const x = Math.random() * width;
        const y = Math.random() * height;
        const r = Math.random() * 50;
        ctx.beginPath();
        ctx.arc(x, y, r, 0, Math.PI * 2);
        ctx.fill();
    }

    // Border
    ctx.strokeStyle = '#8b7750';
    ctx.lineWidth = 3;
    ctx.strokeRect(30, 30, width - 60, height - 60);

    // Title
    ctx.fillStyle = '#5c4033';
    ctx.font = 'bold 28px serif';
    ctx.textAlign = 'center';
    ctx.fillText(title, width / 2, 100);

    // Line under title
    ctx.strokeStyle = '#8b7750';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(100, 115);
    ctx.lineTo(width - 100, 115);
    ctx.stroke();

    // Content text
    ctx.fillStyle = '#3d2b1f';
    ctx.font = '16px serif';
    ctx.textAlign = 'left';

    const words = text.split(' ');
    let line = '';
    let y = 160;
    const lineHeight = 24;
    const maxWidth = width - 100;

    for (const word of words) {
        const testLine = line + word + ' ';
        const metrics = ctx.measureText(testLine);
        if (metrics.width > maxWidth && line.length > 0) {
            ctx.fillText(line, 50, y);
            line = word + ' ';
            y += lineHeight;
        } else {
            line = testLine;
        }
    }
    ctx.fillText(line, 50, y);

    // Footer
    ctx.fillStyle = '#8b7750';
    ctx.font = 'italic 12px serif';
    ctx.textAlign = 'center';
    ctx.fillText('— Document officiel d\'Aetherys —', width / 2, height - 50);

    return canvas.toBuffer('image/png');
}

module.exports = { generatePaperImage };
