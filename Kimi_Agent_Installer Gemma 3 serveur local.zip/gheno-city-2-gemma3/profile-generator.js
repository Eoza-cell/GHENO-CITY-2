const { createCanvas, loadImage } = require('canvas');
const fs = require('fs');
const path = require('path');

async function generateProfileCard(player) {
    const width = 600;
    const height = 800;
    const canvas = createCanvas(width, height);
    const ctx = canvas.getContext('2d');

    // Background
    const gradient = ctx.createLinearGradient(0, 0, width, height);
    gradient.addColorStop(0, '#0f0c29');
    gradient.addColorStop(0.5, '#302b63');
    gradient.addColorStop(1, '#24243e');
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, width, height);

    // Border
    ctx.strokeStyle = '#e94560';
    ctx.lineWidth = 3;
    ctx.strokeRect(15, 15, width - 30, height - 30);

    // Title
    ctx.fillStyle = '#e94560';
    ctx.font = 'bold 28px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('GHENO PHONE - PROFIL', width / 2, 60);

    // Separator
    ctx.strokeStyle = '#e94560';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(50, 75);
    ctx.lineTo(width - 50, 75);
    ctx.stroke();

    // Player Info
    ctx.textAlign = 'left';
    ctx.fillStyle = '#eaeaea';
    ctx.font = 'bold 22px sans-serif';
    ctx.fillText(`${player.name}`, 50, 120);

    ctx.font = '16px sans-serif';
    ctx.fillStyle = '#aaa';
    ctx.fillText(`Classe: ${player.class} (${player.derivative})`, 50, 150);
    ctx.fillText(`Rang: ${player.rank} | Niveau: ${player.level}`, 50, 175);
    ctx.fillText(`Famille: ${player.family}`, 50, 200);
    ctx.fillText(`Métier: ${player.occupation}`, 50, 225);

    // Stats bars
    const drawBar = (label, value, max, color, y) => {
        const barWidth = 400;
        const barHeight = 20;
        const fillWidth = (value / max) * barWidth;

        ctx.fillStyle = '#333';
        ctx.fillRect(50, y, barWidth, barHeight);

        ctx.fillStyle = color;
        ctx.fillRect(50, y, fillWidth, barHeight);

        ctx.fillStyle = '#fff';
        ctx.font = '12px sans-serif';
        ctx.fillText(`${label}: ${value}/${max}`, 55, y + 15);
    };

    drawBar('PV', player.health, player.maxHealth, '#e74c3c', 270);
    drawBar('PM', player.mana, player.maxMana, '#3498db', 310);
    drawBar('XP', player.xp, player.level * 100, '#f39c12', 350);

    // Stats
    ctx.fillStyle = '#eaeaea';
    ctx.font = 'bold 18px sans-serif';
    ctx.fillText('Statistiques', 50, 420);

    const stats = [
        ['Force', player.strength, '#e74c3c'],
        ['Agilité', player.agility, '#2ecc71'],
        ['Intelligence', player.intelligence, '#3498db'],
        ['Défense', player.defense, '#9b59b6'],
        ['Chance', player.luck, '#f1c40f'],
        ['SP', player.skillPoints, '#e67e22']
    ];

    let statY = 450;
    for (const [name, value, color] of stats) {
        ctx.fillStyle = color;
        ctx.fillRect(50, statY - 12, 10, 10);
        ctx.fillStyle = '#eaeaea';
        ctx.font = '16px sans-serif';
        ctx.fillText(`${name}: ${value}`, 70, statY);
        statY += 30;
    }

    // Footer
    ctx.fillStyle = '#666';
    ctx.font = 'italic 12px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText(`Lieu: ${player.location} (${player.subLocation})`, width / 2, height - 50);
    ctx.fillText(`💰 ${player.col} COL`, width / 2, height - 30);

    return canvas.toBuffer('image/png');
}

module.exports = { generateProfileCard };
