/**
 * Utility functions for GHENO CITY 2
 */

function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

function randomInt(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

function clamp(value, min, max) {
    return Math.max(min, Math.min(max, value));
}

function truncate(str, maxLength) {
    if (str.length <= maxLength) return str;
    return str.substring(0, maxLength - 3) + '...';
}

function sanitizeJSON(str) {
    try {
        // Remove markdown code blocks
        str = str.replace(/```json\n?/gi, '').replace(/```\n?/gi, '');
        // Remove leading/trailing whitespace
        str = str.trim();
        // Find first { and last }
        const start = str.indexOf('{');
        const end = str.lastIndexOf('}');
        if (start !== -1 && end !== -1 && end > start) {
            return str.substring(start, end + 1);
        }
        return str;
    } catch (e) {
        return str;
    }
}

module.exports = {
    sleep,
    randomInt,
    clamp,
    truncate,
    sanitizeJSON
};
