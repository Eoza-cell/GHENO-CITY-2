// Simplified 3D visual generator using Canvas (no Three.js runtime dependency for static images)
const { createCanvas } = require('canvas');

async function generate3DVisual(type = 'cube', color = 0x00ffff) {
    const width = 400;
    const height = 400;
    const canvas = createCanvas(width, height);
    const ctx = canvas.getContext('2d');

    // Background
    ctx.fillStyle = '#0a0e27';
    ctx.fillRect(0, 0, width, height);

    // Grid effect
    ctx.strokeStyle = 'rgba(0, 255, 255, 0.1)';
    ctx.lineWidth = 1;
    for (let i = 0; i < width; i += 20) {
        ctx.beginPath();
        ctx.moveTo(i, 0);
        ctx.lineTo(i, height);
        ctx.stroke();
    }
    for (let i = 0; i < height; i += 20) {
        ctx.beginPath();
        ctx.moveTo(0, i);
        ctx.lineTo(width, i);
        ctx.stroke();
    }

    const hexColor = '#' + color.toString(16).padStart(6, '0');

    // Draw shape
    ctx.strokeStyle = hexColor;
    ctx.lineWidth = 2;
    ctx.fillStyle = hexColor + '40';

    const cx = width / 2;
    const cy = height / 2;
    const size = 80;

    if (type === 'sphere') {
        ctx.beginPath();
        ctx.arc(cx, cy, size, 0, Math.PI * 2);
        ctx.fill();
        ctx.stroke();

        // Inner rings
        ctx.strokeStyle = hexColor + '80';
        ctx.beginPath();
        ctx.arc(cx, cy, size * 0.6, 0, Math.PI * 2);
        ctx.stroke();
    } else if (type === 'pyramid') {
        ctx.beginPath();
        ctx.moveTo(cx, cy - size);
        ctx.lineTo(cx + size, cy + size);
        ctx.lineTo(cx - size, cy + size);
        ctx.closePath();
        ctx.fill();
        ctx.stroke();
    } else {
        // Cube
        const offset = size * 0.3;
        // Front face
        ctx.fillStyle = hexColor + '60';
        ctx.fillRect(cx - size / 2, cy - size / 2, size, size);
        ctx.strokeRect(cx - size / 2, cy - size / 2, size, size);

        // Top face
        ctx.fillStyle = hexColor + '30';
        ctx.beginPath();
        ctx.moveTo(cx - size / 2, cy - size / 2);
        ctx.lineTo(cx - size / 2 + offset, cy - size / 2 - offset);
        ctx.lineTo(cx + size / 2 + offset, cy - size / 2 - offset);
        ctx.lineTo(cx + size / 2, cy - size / 2);
        ctx.closePath();
        ctx.fill();
        ctx.stroke();

        // Side face
        ctx.fillStyle = hexColor + '20';
        ctx.beginPath();
        ctx.moveTo(cx + size / 2, cy - size / 2);
        ctx.lineTo(cx + size / 2 + offset, cy - size / 2 - offset);
        ctx.lineTo(cx + size / 2 + offset, cy + size / 2 - offset);
        ctx.lineTo(cx + size / 2, cy + size / 2);
        ctx.closePath();
        ctx.fill();
        ctx.stroke();
    }

    // Scan line animation effect
    ctx.fillStyle = 'rgba(0, 255, 255, 0.1)';
    ctx.fillRect(0, cy - 5, width, 10);

    return canvas.toBuffer('image/png');
}

module.exports = { generate3DVisual };
