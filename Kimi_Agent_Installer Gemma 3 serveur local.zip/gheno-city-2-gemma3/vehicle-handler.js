/**
 * Vehicle handler for GHENO CITY 2
 * Handles vehicle-related commands and logic
 */

const { Player } = require('./database');

const VEHICLES = {
    horse: { name: 'Cheval', speed: 20, price: 500 },
    carriage: { name: 'Carrosse', speed: 15, price: 1500 },
    griffin: { name: 'Griffon', speed: 50, price: 10000 },
    dragon: { name: 'Dragon', speed: 80, price: 50000 }
};

async function getVehicleInfo(vehicleType) {
    return VEHICLES[vehicleType] || null;
}

async function purchaseVehicle(player, vehicleType) {
    const vehicle = VEHICLES[vehicleType];
    if (!vehicle) return { success: false, message: 'Véhicule inconnu.' };
    if (player.col < vehicle.price) return { success: false, message: `Pas assez de COL. Prix: ${vehicle.price}` };
    
    player.col -= vehicle.price;
    await player.save();
    
    return { success: true, message: `Tu as acheté un ${vehicle.name} !` };
}

module.exports = {
    getVehicleInfo,
    purchaseVehicle,
    VEHICLES
};
