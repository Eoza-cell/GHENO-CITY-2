/**
 * Mission system for GHENO CITY 2
 * Handles mission generation, tracking and rewards
 */

const { Op } = require('sequelize');
const { Quest, PlayerQuest } = require('./database');

/**
 * Generate a random mission for a player
 */
async function generateRandomMission(player) {
    const missionTypes = ['hunt', 'gather', 'escort', 'explore', 'duel'];
    const type = missionTypes[Math.floor(Math.random() * missionTypes.length)];
    
    const ranks = ['F', 'E', 'D', 'C', 'B', 'A', 'S'];
    const playerRankIndex = ranks.indexOf(player.rank) || 0;
    const missionRank = ranks[Math.max(0, Math.min(ranks.length - 1, playerRankIndex + randomInt(-1, 2)))];
    
    const titles = {
        hunt: ['Chasse au Gobelin', 'Élimination de Loups', 'Traque de Bandits'],
        gather: ['Collecte d\'Herbes', 'Minage de Cristaux', 'Récolte de Bois'],
        escort: ['Protection de Marchand', 'Escorte Royale', 'Convoi de Ravitaillement'],
        explore: ['Exploration de Ruines', 'Cartographie de la Zone', 'Découverte de Trésor'],
        duel: ['Défi de l\'Arène', 'Combat d\'Honneur', 'Affrontement de Classe']
    };
    
    const typeTitles = titles[type] || titles.hunt;
    const title = typeTitles[Math.floor(Math.random() * typeTitles.length)];
    
    return {
        title: `${title} [${missionRank}]`,
        description: `Mission de type ${type} pour un aventurier de rang ${missionRank}.`,
        type,
        rank: missionRank,
        reward_col: randomInt(50, 500) * (ranks.indexOf(missionRank) + 1),
        reward_xp: randomInt(25, 250) * (ranks.indexOf(missionRank) + 1)
    };
}

function randomInt(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

module.exports = {
    generateRandomMission
};
