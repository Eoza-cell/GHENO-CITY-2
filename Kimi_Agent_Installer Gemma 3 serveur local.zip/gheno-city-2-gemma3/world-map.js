const { createCanvas, loadImage } = require('canvas');

async function generateWorldMapImage() {
    const width = 800;
    const height = 600;
    const canvas = createCanvas(width, height);
    const ctx = canvas.getContext('2d');

    // Background - dark fantasy style
    const gradient = ctx.createLinearGradient(0, 0, 0, height);
    gradient.addColorStop(0, '#0a0e27');
    gradient.addColorStop(1, '#1a1f4b');
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, width, height);

    // Title
    ctx.fillStyle = '#e94560';
    ctx.font = 'bold 32px serif';
    ctx.textAlign = 'center';
    ctx.fillText('AETHERYS - CARTE DU MONDE', width / 2, 50);

    // Kingdom locations as circles
    const kingdoms = [
        { name: 'Empire d\'Elion', x: 300, y: 250, color: '#e74c3c', radius: 40 },
        { name: 'Royaume de Valkyrr', x: 500, y: 200, color: '#3498db', radius: 35 },
        { name: 'Nécropolis', x: 200, y: 400, color: '#2c3e50', radius: 30 },
        { name: 'L\'Interstice', x: 600, y: 400, color: '#8e44ad', radius: 35 },
        { name: 'Royaume Céleste', x: 400, y: 100, color: '#f1c40f', radius: 25 },
        { name: 'Terres Bestiales', x: 150, y: 200, color: '#27ae60', radius: 30 },
        { name: 'Dominion de Vharos', x: 650, y: 300, color: '#c0392b', radius: 30 },
    ];

    // Draw connections
    ctx.strokeStyle = 'rgba(255,255,255,0.2)';
    ctx.lineWidth = 1;
    for (let i = 0; i < kingdoms.length; i++) {
        for (let j = i + 1; j < kingdoms.length; j++) {
            ctx.beginPath();
            ctx.moveTo(kingdoms[i].x, kingdoms[i].y);
            ctx.lineTo(kingdoms[j].x, kingdoms[j].y);
            ctx.stroke();
        }
    }

    // Draw kingdoms
    for (const k of kingdoms) {
        // Glow effect
        const glow = ctx.createRadialGradient(k.x, k.y, 0, k.x, k.y, k.radius + 10);
        glow.addColorStop(0, k.color + '80');
        glow.addColorStop(1, 'transparent');
        ctx.fillStyle = glow;
        ctx.beginPath();
        ctx.arc(k.x, k.y, k.radius + 10, 0, Math.PI * 2);
        ctx.fill();

        // Main circle
        ctx.fillStyle = k.color;
        ctx.beginPath();
        ctx.arc(k.x, k.y, k.radius, 0, Math.PI * 2);
        ctx.fill();

        // Border
        ctx.strokeStyle = '#fff';
        ctx.lineWidth = 2;
        ctx.stroke();

        // Name
        ctx.fillStyle = '#fff';
        ctx.font = 'bold 12px sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText(k.name, k.x, k.y + 5);
    }

    // Legend
    ctx.fillStyle = '#aaa';
    ctx.font = '14px sans-serif';
    ctx.textAlign = 'left';
    ctx.fillText('🟢 Royaumes actifs', 30, height - 30);
    ctx.fillText('⚔️ Conflits possibles entre royaumes connectés', 30, height - 10);

    return canvas.toBuffer('image/png');
}

module.exports = { generateWorldMapImage };
