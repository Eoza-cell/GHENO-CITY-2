const fs = require('fs');
const { Player, Dungeon, Quest, PlayerQuest, Bank, Item, Skill, Entity, Club, Kingdom, NPC, RPMessage, House, TournamentParticipant, Op } = require('./database');
const { generateEquipmentStatusImage } = require('./equipment-visualizer');
const { generateProfileCard } = require('./profile-generator');
const { generateLorePoster } = require('./lore-generator');
const { generateWorldMapImage } = require('./world-map');
const { generateMainMenuImage } = require('./menu-generator');
const { generateShopImage } = require('./shop-generator');
const { handleFreeAction } = require('./ai-handler');
const { startTutorial } = require('./tutorial-handler');
const { sendWithImage, shouldNotifyPlayer } = require('./message-handler');

function getJid(message) {
  if (!message || !message.key) return null;
  if (message.key.remoteJid && message.key.remoteJid.endsWith('@g.us')) {
      return message.key.participant || null;
  }
  return message.key.remoteJid || null;
}

function createStatusBar(current, max, filledChar = '▰', emptyChar = '▱', length = 10) {
    if (max === 0) return emptyChar.repeat(length);
    const percentage = Math.max(0, Math.min(1, current / max));
    const filledCount = Math.round(percentage * length);
    return filledChar.repeat(filledCount) + emptyChar.repeat(length - filledCount);
}

const commands = new Map();

// /ping
commands.set('ping', async (sock, message) => {
    await sock.sendMessage(message.key.remoteJid, { text: "🏓 *Pong !*" });
});

// /start
commands.set('start', async (sock, message) => {
  const jid = getJid(message);
  const player = await Player.findOne({ where: { whatsappId: jid } });
  const replyJid = message.key.remoteJid;

  if (!player) {
    await Player.create({ whatsappId: jid, registrationStep: 'awaiting_name' });
    await sock.sendMessage(replyJid, { text: "*Bienvenue dans Aetheris, Héritier...*\n\nLe monde que tu connaissais n'est plus. Les sceaux se brisent, et l'Essence Primordiale s'éveille en toi.\n\n*LINK START!!*\n\nQuel est ton nom, Héritier ?" });
  } else if (player.registrationStep) {
    await sock.sendMessage(replyJid, { text: "Reprise de l'inscription. Réponds aux questions posées précédemment." });
  } else {
    await sock.sendMessage(replyJid, { text: `« Te revoilà, ${player.name}. L'Interstice s'agite en ton absence... »\n\nUtilise /menu pour commencer.` });
  }
});

// /profile /profil
const profileCommand = async (sock, message) => {
  const jid = getJid(message);
  const player = await Player.findOne({ where: { whatsappId: jid } });
  if (!player) { await sock.sendMessage(message.key.remoteJid, { text: "Commence avec /start." }); return; }

  try {
      const profileBuffer = await generateProfileCard(player);
      const healthBar = createStatusBar(player.health, player.maxHealth);
      const manaBar = createStatusBar(player.mana, player.maxMana);
      const xpNeeded = player.level * 100;
      const xpBar = createStatusBar(player.xp, xpNeeded);

      const profileText = `--- 🆔 GHENO PHONE - PROFIL --- \n\n👤 *HÉRITIER:* ${player.name}\n⚧️ *SEXE:* ${player.gender}\n🎂 *ÂGE:* ${player.age}\n👪 *FAMILLE:* ${player.family}\n🎭 *CLASSE:* ${player.class} (${player.derivative})\n🎖️ *RANG:* ${player.rank}\n📊 *NIVEAU:* ${player.level}\n\n❤️ *VIE:*  [${healthBar}] ${player.health}/${player.maxHealth}\n🔷 *MANA:* [${manaBar}] ${player.mana}/${player.maxMana}\n✨ *XP:*   [${xpBar}] ${player.xp}/${xpNeeded}\n\n--- ⚔️ STATS --- \n💪 FOR: ${player.strength} | 🏃 AGI: ${player.agility}\n🧠 INT: ${player.intelligence} | 🛡️ DEF: ${player.defense}\n🍀 LUK: ${player.luck} | ✨ SP: ${player.skillPoints}\n\n💰 *COL:* ${player.col} 🪙\n📍 *LIEU:* ${player.location} (${player.subLocation})`;

      await sock.sendMessage(message.key.remoteJid, { image: profileBuffer, caption: profileText });
  } catch (e) { console.error(e); await sock.sendMessage(message.key.remoteJid, { text: "Erreur génération profil." }); }
};
commands.set('profile', profileCommand);
commands.set('profil', profileCommand);

// /action
commands.set('action', async (sock, message) => {
  const jid = getJid(message);
  const player = await Player.findOne({ where: { whatsappId: jid } });
  if (player) { await player.update({ mode: 'action' }); await sock.sendMessage(message.key.remoteJid, { text: "Mode action activé. Décris tes actions en langage naturel." }); }
  else { await sock.sendMessage(message.key.remoteJid, { text: "Commence avec /start." }); }
});

// /next
commands.set('next', async (sock, message) => {
  const jid = getJid(message);
  const player = await Player.findOne({ where: { whatsappId: jid } });
  if (!player) { await sock.sendMessage(message.key.remoteJid, { text: "Commence avec /start." }); return; }
  try { await handleFreeAction(sock, message, player, "next"); } catch (e) { console.error(e); }
});

// /quests
commands.set('quests', async (sock, message) => {
  const jid = getJid(message);
  const player = await Player.findOne({ where: { whatsappId: jid }, include: Quest });
  if (!player) { await sock.sendMessage(message.key.remoteJid, { text: "Commence avec /start." }); return; }

  const active = player.Quests.filter(q => q.PlayerQuest.status === 'in_progress');
  const notStarted = player.Quests.filter(q => q.PlayerQuest.status === 'not_started');

  let text = '╔══════════════════════════╗\n   📜 *JOURNAL DES QUÊTES*   \n╚══════════════════════════╝\n\n';
  if (active.length > 0) { text += '⚔️ *ACTIVES*\n' + active.map(q => `├ ${q.title} [${q.PlayerQuest.progress}%]`).join('\n') + '\n\n'; }
  if (notStarted.length > 0) { text += '📍 *DÉCOUVERTES*\n' + notStarted.map(q => `└ ${q.title}`).join('\n'); }
  if (active.length === 0 && notStarted.length === 0) text += "🌀 Aucune quête active.";
  await sock.sendMessage(message.key.remoteJid, { text });
});

// /inventory
commands.set('inventory', async (sock, message) => {
  const jid = getJid(message);
  const player = await Player.findOne({ where: { whatsappId: jid } });
  if (!player) { await sock.sendMessage(message.key.remoteJid, { text: "Commence avec /start." }); return; }

  const inv = player.inventory;
  if (inv.length === 0) { await sock.sendMessage(message.key.remoteJid, { text: "Inventaire vide." }); return; }

  const invText = inv.map(item => `├ ${item.name} (x${item.quantity})`).join('\n');
  await sock.sendMessage(message.key.remoteJid, { text: `--- 🎒 INVENTAIRE --- \n\n${invText}` });
});

// /competences
commands.set('competences', async (sock, message) => {
  const jid = getJid(message);
  const player = await Player.findOne({ where: { whatsappId: jid }, include: Skill });
  if (!player) { await sock.sendMessage(message.key.remoteJid, { text: "Commence avec /start." }); return; }

  const skills = player.Skills;
  if (!skills || skills.length === 0) { await sock.sendMessage(message.key.remoteJid, { text: "Aucune compétence. Étudie à l'Académie !" }); return; }

  let text = `*Compétences de ${player.name}:*\n\n`;
  skills.forEach(s => { text += `├ *${s.name}* 💠${s.manaCost}PM\n└ ${s.description}\n\n`; });
  await sock.sendMessage(message.key.remoteJid, { text });
});

// /map
commands.set('map', async (sock, message) => {
  const jid = getJid(message);
  const player = await Player.findOne({ where: { whatsappId: jid } });
  if (!player) { await sock.sendMessage(message.key.remoteJid, { text: "Commence avec /start." }); return; }

  const dungeons = await Dungeon.findAll();
  const mapText = `🗺️ *CARTE D'AETHERYS*\n\n📍 *Position:* ${player.location}\n\n🏰 *Donjons:*\n${dungeons.map(d => `├ ${d.name} (Rang ${d.rank})`).join('\n')}`;

  try { const mapImage = await generateWorldMapImage(); await sock.sendMessage(message.key.remoteJid, { image: mapImage, caption: mapText }); }
  catch (e) { await sock.sendMessage(message.key.remoteJid, { text: mapText }); }
});

// /bank /banque
const bankCommand = async (sock, message) => {
  const jid = getJid(message);
  const player = await Player.findOne({ where: { whatsappId: jid } });
  if (!player) { await sock.sendMessage(message.key.remoteJid, { text: "Commence avec /start." }); return; }

  const [bank] = await Bank.findOrCreate({ where: { PlayerWhatsappId: player.whatsappId } });
  await bank.reload();

  await sock.sendMessage(message.key.remoteJid, { text: `--- 🏦 BANQUE --- \n👤 ${player.name}\n💰 Espèces: ${player.col} 🪙\n💳 Solde: ${bank.balance} 🪙\n\n/deposer <montant> | /retirer <montant>` });
};
commands.set('bank', bankCommand);
commands.set('banque', bankCommand);

// /deposer
commands.set('deposer', async (sock, message, args) => {
  const jid = getJid(message);
  const player = await Player.findOne({ where: { whatsappId: jid } });
  const amount = parseInt(args[0]);
  if (!player || isNaN(amount) || amount <= 0) { await sock.sendMessage(message.key.remoteJid, { text: "Usage: /deposer <montant>" }); return; }
  if (player.col < amount) { await sock.sendMessage(message.key.remoteJid, { text: "Pas assez de Col." }); return; }

  const [bank] = await Bank.findOrCreate({ where: { PlayerWhatsappId: jid } });
  await player.decrement('col', { by: amount });
  await bank.increment('balance', { by: amount });
  await sock.sendMessage(message.key.remoteJid, { text: `🏦 Dépôt: ${amount} Col. Solde: ${bank.balance + amount} Col.` });
});

// /retirer
commands.set('retirer', async (sock, message, args) => {
  const jid = getJid(message);
  const player = await Player.findOne({ where: { whatsappId: jid } });
  const amount = parseInt(args[0]);
  if (!player || isNaN(amount) || amount <= 0) { await sock.sendMessage(message.key.remoteJid, { text: "Usage: /retirer <montant>" }); return; }

  const [bank] = await Bank.findOrCreate({ where: { PlayerWhatsappId: jid } });
  await bank.reload();
  if (bank.balance < amount) { await sock.sendMessage(message.key.remoteJid, { text: "Solde insuffisant." }); return; }

  await bank.decrement('balance', { by: amount });
  await player.increment('col', { by: amount });
  await sock.sendMessage(message.key.remoteJid, { text: `🏦 Retrait: ${amount} Col.` });
});

// /boutique
commands.set('boutique', async (sock, message) => {
  const items = await Item.findAll({ where: { type: { [Op.ne]: 'clothing' } }, order: [['price', 'ASC']], limit: 8 });
  if (items.length === 0) { await sock.sendMessage(message.key.remoteJid, { text: "Boutique vide." }); return; }

  try { const shopImage = await generateShopImage("FORGE DE BROKK", items); await sock.sendMessage(message.key.remoteJid, { image: shopImage, caption: "⚔️ ÉQUIPEMENT\nUtilise /acheter [nom]" }); }
  catch (e) { await sock.sendMessage(message.key.remoteJid, { text: "Erreur génération boutique." }); }
});

// /acheter
commands.set('acheter', async (sock, message, args) => {
  const jid = getJid(message);
  const player = await Player.findOne({ where: { whatsappId: jid } });
  const itemName = args.join(' ');
  if (!player || !itemName) return;

  const item = await Item.findOne({ where: { name: { [Op.like]: `%${itemName}%` } } });
  if (!item) { await sock.sendMessage(message.key.remoteJid, { text: "Objet non disponible." }); return; }
  if (player.col < item.price) { await sock.sendMessage(message.key.remoteJid, { text: `Pas assez de Col (${item.price} requis).` }); return; }

  await player.decrement('col', { by: item.price });
  let inv = [...player.inventory];
  const existing = inv.find(i => i.name === item.name);
  if (existing) existing.quantity += 1; else inv.push({ name: item.name, quantity: 1 });
  player.inventory = inv; await player.save();
  await sock.sendMessage(message.key.remoteJid, { text: `🛒 Acheté: ${item.name} pour ${item.price} Col.` });
});

// /top
commands.set('top', async (sock, message) => {
  const topPlayers = await Player.findAll({ order: [['level', 'DESC'], ['xp', 'DESC']], limit: 10 });
  let text = "🏆 *CLASSEMENT*\n\n";
  topPlayers.forEach((p, i) => { const medal = i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : '👤'; text += `${medal} ${p.name} (Niv ${p.level})\n`; });
  await sock.sendMessage(message.key.remoteJid, { text });
});

// /joueurs
commands.set('joueurs', async (sock, message) => {
  const jid = getJid(message);
  const player = await Player.findOne({ where: { whatsappId: jid } });
  if (!player) { await sock.sendMessage(message.key.remoteJid, { text: "Commence avec /start." }); return; }

  const others = await Player.findAll({ where: { location: player.location, whatsappId: { [Op.ne]: jid } } });
  if (others.length === 0) { await sock.sendMessage(message.key.remoteJid, { text: `Tu es seul à ${player.location}.` }); return; }

  let text = "--- 👥 HÉRITIERS PROCHES --- \n\n";
  others.forEach(p => { text += `*${p.name}* | Niv ${p.level} | ${p.subLocation}\n`; });
  await sock.sendMessage(message.key.remoteJid, { text });
});

// /royaumes
commands.set('royaumes', async (sock, message) => {
  const kingdoms = await Kingdom.findAll();
  let text = "--- 🏰 ROYAUMES --- \n\n";
  kingdoms.forEach(k => { text += `*${k.name.toUpperCase()}*\n├ 👑 ${k.leader}\n└ 📜 ${k.description.substring(0, 100)}...\n\n`; });
  await sock.sendMessage(message.key.remoteJid, { text });
});

// /lieux
commands.set('lieux', async (sock, message) => {
  const jid = getJid(message);
  const player = await Player.findOne({ where: { whatsappId: jid } });
  if (!player) return;
  await sock.sendMessage(message.key.remoteJid, { text: `📍 *Position:*\n🌍 ${player.location}\n📌 ${player.subLocation}\n\nDéplace-toi via /action.` });
});

// /lore
commands.set('lore', async (sock, message, args) => {
  const topic = args.join(' ').trim();
  if (!topic) {
    await sock.sendMessage(message.key.remoteJid, { text: "📚 *BIBLIOTHÈQUE*\nUtilise /lore <sujet>\n\nSujets: One Above All, Apôtres, Interstice, Nécropolis, Convergence..." });
    return;
  }

  const worldLore = {
    'one above all': "Source première de l'existence. Aucun temple ne peut le contenir.",
    'apôtres': "Anciens humains ayant sacrifié leur humanité pour un pouvoir divin.",
    'interstice': "Dimension entre les mondes où règne la loi du plus fort.",
    'béhérit': "Reliques vivantes apparaissant lors du désespoir absolu.",
    'necropolis': "Cité des morts, gouvernée par Orpheon.",
    'convergence': "Moment où les limites entre les dimensions cessent de tenir."
  };

  const key = Object.keys(worldLore).find(k => k.includes(topic.toLowerCase()) || topic.toLowerCase().includes(k));
  if (key) {
    try { const poster = await generateLorePoster(key, worldLore[key], 'LORE'); await sock.sendMessage(message.key.remoteJid, { image: poster, caption: `📚 ${key.toUpperCase()}\n\n${worldLore[key]}` }); }
    catch (e) { await sock.sendMessage(message.key.remoteJid, { text: `📚 ${key.toUpperCase()}\n${worldLore[key]}` }); }
  } else {
    await sock.sendMessage(message.key.remoteJid, { text: `❌ Aucune archive pour "${topic}".` });
  }
});

// /pacts
commands.set('pacts', async (sock, message) => {
  const jid = getJid(message);
  const player = await Player.findOne({ where: { whatsappId: jid }, include: 'Entities' });
  if (!player) return;

  const entities = await Entity.findAll();
  let text = "--- ✨ PACTES --- \n\n";
  if (player.Entities?.length > 0) { text += "*Tes Pactes:*\n" + player.Entities.map(e => `🔥 ${e.name} (${e.type})`).join('\n') + "\n\n"; }
  text += "*Entités connues:*\n" + entities.map(e => `❓ ${e.name}`).join('\n');
  await sock.sendMessage(message.key.remoteJid, { text });
});

// /clubs
commands.set('clubs', async (sock, message) => {
  const jid = getJid(message);
  const player = await Player.findOne({ where: { whatsappId: jid }, include: 'Clubs' });
  if (!player) return;

  const clubs = await Club.findAll();
  let text = "--- 🏫 CLUBS --- \n\n";
  clubs.forEach(c => { text += `*${c.name}*\n├ ${c.specialty}\n└ 👑 ${c.leaderName}\n\n`; });
  await sock.sendMessage(message.key.remoteJid, { text });
});

// /up
commands.set('up', async (sock, message, args) => {
  const jid = getJid(message);
  const player = await Player.findOne({ where: { whatsappId: jid } });
  if (!player) return;

  if (args.length === 0) {
    await sock.sendMessage(message.key.remoteJid, { text: `--- 📈 AMÉLIORATION ---\n✨ SP: ${player.skillPoints}\n\n/up <stat> <points>\nFOR | AGI | INT | DEF | LUK` });
    return;
  }

  const statMap = { 'for': 'strength', 'force': 'strength', 'agi': 'agility', 'agilité': 'agility', 'int': 'intelligence', 'def': 'defense', 'défense': 'defense', 'luk': 'luck', 'chance': 'luck' };
  const targetStat = statMap[args[0].toLowerCase()];
  const points = parseInt(args[1]) || 1;

  if (!targetStat) { await sock.sendMessage(message.key.remoteJid, { text: "Stat invalide." }); return; }
  if (player.skillPoints < points) { await sock.sendMessage(message.key.remoteJid, { text: "Pas assez de SP." }); return; }

  await player.decrement('skillPoints', { by: points });
  await player.increment(targetStat, { by: points });
  await player.reload();
  await sock.sendMessage(message.key.remoteJid, { text: `✅ ${args[0].toUpperCase()}: +${points} → ${player[targetStat]}\nSP restants: ${player.skillPoints}` });
});

// /menu
commands.set('menu', async (sock, message) => {
  const jid = getJid(message);
  const player = await Player.findOne({ where: { whatsappId: jid } });
  if (player) await player.update({ mode: 'normal' });

  const menuText = "╔══════════════════════════╗\n   🌐 *ARISE : GHENO CITY*\n╚══════════════════════════╝\n\n🕹️ `/action` - Mode RP\n👤 `/profil` - Profil | `/inventory` - Sac\n📍 `/map` - Carte | `/quests` - Quêtes\n💰 `/bank` - Banque | `/boutique` - Shop\n🏛️ `/lore` - Lore | `/pacts` - Pactes\n🏆 `/top` - Classement\n⚙️ `/help` - Aide";

  try { const menuImage = await generateMainMenuImage(); await sock.sendMessage(message.key.remoteJid, { image: menuImage, caption: menuText }); }
  catch (e) { await sock.sendMessage(message.key.remoteJid, { text: menuText }); }
});

// /help
commands.set('help', async (sock, message) => {
  const helpText = "*Commandes:*\n/start /menu /profile /action /next /quests /inventory /competences /map /bank /deposer /retirer /boutique /acheter /top /joueurs /lieux /royaumes /pacts /clubs /lore /up /statut /save /help";
  await sock.sendMessage(message.key.remoteJid, { text: helpText });
});

// /statut
commands.set('statut', async (sock, message) => {
  const jid = getJid(message);
  const player = await Player.findOne({ where: { whatsappId: jid } });
  if (!player) return;

  try { const img = await generateEquipmentStatusImage({ head: false, chest: !!player.equippedOutfit, arms: false, legs: false, weapon: false }); await sock.sendMessage(message.key.remoteJid, { image: img, caption: `Équipement de ${player.name}` }); }
  catch (e) { await sock.sendMessage(message.key.remoteJid, { text: `Équipement: ${player.equippedOutfit || 'Aucun'}` }); }
});

// /save
commands.set('save', async (sock, message) => {
  const jid = getJid(message);
  const player = await Player.findOne({ where: { whatsappId: jid } });
  if (!player) { await sock.sendMessage(message.key.remoteJid, { text: "Commence avec /start." }); return; }
  await player.save();
  await sock.sendMessage(message.key.remoteJid, { text: "💾 Sauvegarde réussie !" });
});

// /checkai
commands.set('checkai', async (sock, message) => {
  const { callAI } = require('./ai-utils');
  await sock.sendMessage(message.key.remoteJid, { text: "🔍 Diagnostic IA en cours..." });
  try {
    const result = await callAI("Test", "Réponds 'OK'.", { skipWorldServer: false });
    await sock.sendMessage(message.key.remoteJid, { text: `🟢 IA Opérationnelle\nModèle: ${process.env.OLLAMA_MODEL || 'gemma3:4b'}\nRéponse: ${result?.substring(0, 100)}` });
  } catch (e) {
    await sock.sendMessage(message.key.remoteJid, { text: "🔴 IA Indisponible. Vérifie Ollama: ollama serve" });
  }
});

// /reset
commands.set('reset', async (sock, message, args) => {
  const jid = getJid(message);
  const player = await Player.findOne({ where: { whatsappId: jid } });
  if (!player) { await sock.sendMessage(message.key.remoteJid, { text: "Pas de personnage." }); return; }
  if (args[0] !== 'confirm') {
    await sock.sendMessage(message.key.remoteJid, { text: "⚠️ `/reset confirm` pour supprimer définitivement." });
    return;
  }
  await Bank.destroy({ where: { PlayerWhatsappId: jid } });
  await player.destroy();
  await sock.sendMessage(message.key.remoteJid, { text: "💥 Personnage réinitialisé. Utilise /start pour renaître." });
});

// /god
commands.set('god', async (sock, message, args) => {
  const jid = getJid(message);
  const player = await Player.findOne({ where: { whatsappId: jid } });
  if (!player) return;

  if (args[0] === '201148') {
    await player.update({ isGod: true });
    await sock.sendMessage(message.key.remoteJid, { text: "✨ Statut divin accordé." });
    return;
  }
  if (!player.isGod) { await sock.sendMessage(message.key.remoteJid, { text: "Accès réservé." }); return; }

  // Admin commands
  const sub = args.shift()?.toLowerCase();
  switch(sub) {
    case 'set': { const stat = args[0], val = parseInt(args[1]); if(stat && !isNaN(val)) { await player.update({ [stat]: val }); await sock.sendMessage(message.key.remoteJid, { text: `${stat} = ${val}` }); } break; }
    case 'col': { const amt = parseInt(args[0]); if(!isNaN(amt)) { await player.increment('col', { by: amt }); await sock.sendMessage(message.key.remoteJid, { text: `+${amt} Col` }); } break; }
    case 'max': { await player.update({ strength: 999, agility: 999, intelligence: 999, defense: 999, luck: 999, level: 100 }); await sock.sendMessage(message.key.remoteJid, { text: "Stats max !" }); break; }
    default: await sock.sendMessage(message.key.remoteJid, { text: "Commandes: /god set <stat> <val>, /god col <amt>, /god max" });
  }
});

// Main handler
async function handleCommand(sock, message, downloadMediaMessage) {
  if (message.key.fromMe) return;

  const messageText = message.message.conversation || message.message.extendedTextMessage?.text;
  if (!messageText) return;

  const jid = getJid(message);
  const replyJid = message.key.remoteJid;
  const senderName = message.pushName || jid;

  console.log(`[MSG] "${senderName}" (${jid}): "${messageText}"`);

  const player = await Player.findOne({ where: { whatsappId: jid } });

  // Registration flow
  if (player && player.registrationStep) {
      if (player.registrationStep === 'awaiting_name') {
          const name = messageText.trim();
          if (name.length > 2 && name.length <= 20 && !name.startsWith('/')) {
              await player.update({ name, registrationStep: 'awaiting_gender' });
              await Bank.findOrCreate({ where: { PlayerWhatsappId: jid } });
              await sock.sendMessage(replyJid, { text: `« ${name}... Un nom qui résonnera dans l'Interstice. »\n\nQuel est ton sexe ?` });
          } else { await sock.sendMessage(replyJid, { text: "Nom invalide (3-20 caractères)." }); }
      } else if (player.registrationStep === 'awaiting_gender') {
          await player.update({ gender: messageText.trim(), registrationStep: 'awaiting_age' });
          await sock.sendMessage(replyJid, { text: "Quel est ton âge ?" });
      } else if (player.registrationStep === 'awaiting_age') {
          const age = parseInt(messageText.trim());
          if (!isNaN(age) && age > 0 && age < 150) {
              await player.update({ age, registrationStep: 'awaiting_description' });
              await sock.sendMessage(replyJid, { text: "Décris ton personnage en une phrase." });
          } else { await sock.sendMessage(replyJid, { text: "Âge invalide." }); }
      } else if (player.registrationStep === 'awaiting_description') {
          const desc = messageText.trim();
          if (desc.length > 10 && desc.length <= 150) {
              await player.update({ characterDescription: desc, registrationStep: null, awaitingProfilePic: true });
              await sock.sendMessage(replyJid, { text: "Description enregistrée ! Envoie une image pour ton profil." });
          } else { await sock.sendMessage(replyJid, { text: "Description trop courte/longue (10-150 caractères)." }); }
      }
      return;
  }

  if (!player && !messageText.startsWith('/start')) {
    await sock.sendMessage(replyJid, { text: "Utilise /start pour commencer." });
    return;
  }

  // Action mode
  if (player?.mode === 'action' && !messageText.startsWith('/')) {
    try {
        if (player.tutorialStep >= 0 && player.tutorialStep < 3) {
            const { handleTutorialAction } = require('./tutorial-handler');
            await handleTutorialAction(sock, message, player, messageText);
        } else {
            await handleFreeAction(sock, message, player, messageText);
        }
    } catch (error) {
      console.error('Erreur action:', error);
      await sock.sendMessage(replyJid, { text: "Le MJ n'a pas pu interpréter ton action." });
    } finally {
        await player.update({ lastActivity: new Date() });
    }
    return;
  }

  // Commands
  if (!messageText.startsWith('/')) return;

  const args = messageText.slice(1).trim().split(/ +/);
  const commandName = args.shift().toLowerCase();
  const command = commands.get(commandName);

  if (command) {
    try {
      await command(sock, message, args);
      if (player) await player.update({ lastActivity: new Date() });
    } catch (error) {
      console.error(`Erreur ${commandName}:`, error);
      await sock.sendMessage(replyJid, { text: "Erreur lors de l'exécution." });
    }
  } else {
    await sock.sendMessage(replyJid, { text: "Commande inconnue. Tape /help." });
  }
}

module.exports = { handleCommand, getJid };
