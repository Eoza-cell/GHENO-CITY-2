const { createCanvas } = require('canvas');

async function generateShopImage(shopName, items) {
    const width = 600;
    const height = 400 + Math.max(0, (items.length - 5) * 50);
    const canvas = createCanvas(width, height);
    const ctx = canvas.getContext('2d');

    // Background
    const gradient = ctx.createLinearGradient(0, 0, 0, height);
    gradient.addColorStop(0, '#1a1a2e');
    gradient.addColorStop(1, '#16213e');
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, width, height);

    // Border
    ctx.strokeStyle = '#e94560';
    ctx.lineWidth = 3;
    ctx.strokeRect(15, 15, width - 30, height - 30);

    // Shop name
    ctx.fillStyle = '#e94560';
    ctx.font = 'bold 28px serif';
    ctx.textAlign = 'center';
    ctx.fillText(shopName, width / 2, 60);

    // Separator
    ctx.strokeStyle = '#e94560';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(50, 80);
    ctx.lineTo(width - 50, 80);
    ctx.stroke();

    // Items
    ctx.textAlign = 'left';
    let y = 120;

    for (const item of items.slice(0, 10)) {
        // Rarity color
        const rarityColors = {
            common: '#95a5a6',
            rare: '#3498db',
            epic: '#9b59b6',
            legendary: '#f39c12'
        };
        const color = rarityColors[item.rarity] || '#95a5a6';

        ctx.fillStyle = color;
        ctx.font = 'bold 16px sans-serif';
        ctx.fillText(item.name, 50, y);

        ctx.fillStyle = '#f1c40f';
        ctx.font = '14px sans-serif';
        ctx.textAlign = 'right';
        ctx.fillText(`${item.price} COL`, width - 50, y);

        ctx.textAlign = 'left';
        ctx.fillStyle = '#aaa';
        ctx.font = '12px sans-serif';
        ctx.fillText(item.description?.substring(0, 50) || '', 50, y + 18);

        y += 50;
    }

    return canvas.toBuffer('image/png');
}

module.exports = { generateShopImage };
