const { createCanvas } = require('canvas');

async function generateEquipmentStatusImage(equipped) {
    const width = 400;
    const height = 300;
    const canvas = createCanvas(width, height);
    const ctx = canvas.getContext('2d');

    ctx.fillStyle = '#1a1a2e';
    ctx.fillRect(0, 0, width, height);

    ctx.strokeStyle = '#e94560';
    ctx.lineWidth = 2;
    ctx.strokeRect(15, 15, width - 30, height - 30);

    ctx.fillStyle = '#e94560';
    ctx.font = 'bold 20px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('ÉQUIPEMENT', width / 2, 50);

    const slots = [
        ['head', 'Tête', 50, 100],
        ['chest', 'Torse', 50, 140],
        ['arms', 'Bras', 50, 180],
        ['legs', 'Jambes', 50, 220],
        ['weapon', 'Arme', 200, 100]
    ];

    for (const [key, label, x, y] of slots) {
        const isEquipped = equipped[key];
        ctx.fillStyle = isEquipped ? '#2ecc71' : '#e74c3c';
        ctx.font = '16px sans-serif';
        ctx.textAlign = 'left';
        ctx.fillText(`${isEquipped ? '🟢' : '⚪'} ${label}`, x, y);
    }

    return canvas.toBuffer('image/png');
}

module.exports = { generateEquipmentStatusImage };
