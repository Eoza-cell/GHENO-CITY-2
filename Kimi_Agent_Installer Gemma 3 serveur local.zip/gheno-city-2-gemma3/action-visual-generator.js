const { createCanvas } = require('canvas');

async function generateActionVisual({ actionType, title, description, assetPath }) {
    const width = 600;
    const height = 300;
    const canvas = createCanvas(width, height);
    const ctx = canvas.getContext('2d');

    // Background based on action type
    const bgColors = {
        attack: ['#2c0000', '#000000'],
        defend: ['#001a2c', '#000000'],
        magic: ['#1a0033', '#000000'],
        combat: ['#2c1a00', '#000000']
    };
    const colors = bgColors[actionType] || bgColors.combat;

    const gradient = ctx.createLinearGradient(0, 0, 0, height);
    gradient.addColorStop(0, colors[0]);
    gradient.addColorStop(1, colors[1]);
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, width, height);

    // Scan lines
    ctx.fillStyle = 'rgba(255, 0, 0, 0.03)';
    for (let i = 0; i < height; i += 2) {
        ctx.fillRect(0, i, width, 1);
    }

    // Border
    ctx.strokeStyle = '#e94560';
    ctx.lineWidth = 2;
    ctx.strokeRect(15, 15, width - 30, height - 30);

    // Type indicator
    ctx.fillStyle = '#e94560';
    ctx.font = 'bold 12px monospace';
    ctx.textAlign = 'left';
    ctx.fillText(`[${actionType.toUpperCase()}]`, 30, 40);

    // Title
    ctx.fillStyle = '#fff';
    ctx.font = 'bold 20px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText(title, width / 2, 80);

    // Description
    ctx.fillStyle = '#aaa';
    ctx.font = '14px sans-serif';
    const words = description.split(' ');
    let line = '';
    let y = 120;
    const maxWidth = width - 100;

    for (const word of words) {
        const testLine = line + word + ' ';
        const metrics = ctx.measureText(testLine);
        if (metrics.width > maxWidth && line.length > 0) {
            ctx.fillText(line, width / 2, y);
            line = word + ' ';
            y += 22;
        } else {
            line = testLine;
        }
    }
    ctx.fillText(line, width / 2, y);

    return canvas.toBuffer('image/png');
}

module.exports = { generateActionVisual };
