const { createCanvas, loadImage } = require('canvas');

async function generateMainMenuImage() {
    const width = 600;
    const height = 400;
    const canvas = createCanvas(width, height);
    const ctx = canvas.getContext('2d');

    // Dark gradient background
    const gradient = ctx.createLinearGradient(0, 0, width, height);
    gradient.addColorStop(0, '#000000');
    gradient.addColorStop(0.5, '#1a0033');
    gradient.addColorStop(1, '#000033');
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, width, height);

    // Decorative border
    ctx.strokeStyle = '#e94560';
    ctx.lineWidth = 3;
    ctx.strokeRect(20, 20, width - 40, height - 40);

    // Inner glow border
    ctx.strokeStyle = 'rgba(233, 69, 96, 0.3)';
    ctx.lineWidth = 1;
    ctx.strokeRect(25, 25, width - 50, height - 50);

    // Title
    ctx.fillStyle = '#e94560';
    ctx.font = 'bold 36px serif';
    ctx.textAlign = 'center';
    ctx.fillText('ARISE', width / 2, 120);

    ctx.fillStyle = '#aaa';
    ctx.font = 'italic 18px serif';
    ctx.fillText('GHENO CITY 2', width / 2, 150);

    // Subtitle
    ctx.fillStyle = '#666';
    ctx.font = '14px sans-serif';
    ctx.fillText('Interface de Connexion', width / 2, 180);

    // Decorative line
    ctx.strokeStyle = '#e94560';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(150, 210);
    ctx.lineTo(width - 150, 210);
    ctx.stroke();

    // Status indicators
    ctx.fillStyle = '#2ecc71';
    ctx.font = '12px monospace';
    ctx.textAlign = 'left';
    ctx.fillText('● IA Locale: Gemma 3', 80, 250);
    ctx.fillText('● Base de données: Connectée', 80, 275);
    ctx.fillText('● WhatsApp: En attente', 80, 300);

    ctx.fillStyle = '#e94560';
    ctx.textAlign = 'center';
    ctx.font = 'italic 12px sans-serif';
    ctx.fillText('Tapez /start pour commencer', width / 2, 360);

    return canvas.toBuffer('image/png');
}

module.exports = { generateMainMenuImage };
