# GHENO CITY 2 - Serveur Gemma 3 Local

**ARISE : GHENO CITY 2** est un jeu RPG immersif fonctionnant sur WhatsApp, propulsé par l'IA **Gemma 3** de Google exécutée **localement** via Ollama. Ce projet est une version améliorée de GHENO-CITY-2 avec un serveur d'IA local autonome.

## Caractéristiques

- **IA Locale Gemma 3** - Plus besoin de clés API ! L'IA tourne entièrement sur votre machine
- **Jeu RPG sur WhatsApp** - Système complet de classes, quêtes, combats, économie
- **Monde vivant** - Royaumes, factions, PNJ, donjons, conflits dynamiques
- **Multi-joueurs** - Synchronisation des actions, tournois PVP, échanges
- **Base de données** - PostgreSQL ou SQLite pour la persistance

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    GHENO CITY 2.0                          │
├──────────────────────┬──────────────────────────────────────┤
│   WhatsApp Bot       │   World Intelligence Server          │
│   (skype-bot.js)     │   (model-server.js)                  │
│                      │                                      │
│  - Commandes         │  - API compatible OpenAI             │
│  - Base de données   │  - Gemma 3 via Ollama                │
│  - Visuals           │  - Contexte monde enrichi            │
│  - Actions MJ        │  - Health check endpoint             │
└──────────┬───────────┴──────────────┬───────────────────────┘
           │                          │
           ▼                          ▼
    ┌─────────────┐           ┌──────────────┐
    │  Baileys    │           │   Ollama     │
    │  (WhatsApp) │           │  (Gemma 3)   │
    └─────────────┘           └──────────────┘
```

## Prérequis

- **Node.js** 18+ 
- **Ollama** installé : [https://ollama.com](https://ollama.com)
- **Gemma 3** téléchargé : `ollama pull gemma3:4b` (ou `gemma3:12b`)
- Un numéro de téléphone WhatsApp pour le bot

## Installation Rapide

### 1. Installer Ollama et Gemma 3

```bash
# Installer Ollama (Linux/Mac)
curl -fsSL https://ollama.com/install.sh | sh

# Ou télécharger depuis https://ollama.com pour Windows

# Télécharger Gemma 3 (version 4B = ~3GB, version 12B = ~8GB)
ollama pull gemma3:4b

# Vérifier que le modèle est installé
ollama list
```

### 2. Cloner et Configurer le Projet

```bash
git clone https://github.com/Eoza-cell/GHENO-CITY-2.git
cd GHENO-CITY-2

# Copier le fichier d'environnement
cp .env.example .env

# Éditer .env avec vos paramètres
nano .env
```

### 3. Configurer le fichier .env

```env
# OBLIGATOIRE - Votre numéro WhatsApp avec indicatif pays
PHONE_NUMBER=33612345678

# Ollama / Gemma 3 (déjà configuré par défaut)
OLLAMA_URL=http://localhost:11434
OLLAMA_MODEL=gemma3:4b

# API Externes (optionnel - fallbacks)
# PUTER_API_KEY=votre_clé_puter
# OPENROUTER_API_KEY=votre_clé_openrouter
```

### 4. Installer les Dépendances

```bash
npm install
```

> **Note** : L'installation de `sharp` et `sqlite3` peut prendre du temps car ils compilent des modules natifs.

### 5. Démarrer

```bash
# Mode simple - Démarre le bot + le serveur Gemma 3
npm start

# Ou démarrer séparément :
# Terminal 1 - Serveur IA Gemma 3
npm run server

# Terminal 2 - Bot WhatsApp
node skype-bot.js

# Mode développement (les deux en parallèle)
npm run dev
```

### 6. Connecter WhatsApp

Au premier démarrage, un **code de pairage** s'affiche dans le terminal :

```
==============================================================
Votre code de pairage :
➡️➡️➡️   ABCD-EFGH   ⬅️⬅️⬅️
==============================================================
```

1. Ouvrez **WhatsApp** sur votre téléphone
2. Allez dans **Paramètres > Appareils connectés**
3. Appuyez sur **"Connecter un appareil"**
4. Choisissez **"Connecter avec numéro de téléphone"**
5. Entrez le code affiché

## Commandes du Jeu

### Commandes Principales
| Commande | Description |
|----------|-------------|
| `/start` | Commencer l'aventure |
| `/menu` | Menu principal |
| `/profile` | Voir ton profil |
| `/action` | Mode RP immersif |
| `/next` | Forcer la réponse du MJ |
| `/quests` | Journal de quêtes |
| `/map` | Carte du monde |
| `/inventory` | Inventaire |
| `/competences` | Techniques et sorts |
| `/bank` | Compte en banque |
| `/boutique` | Boutique d'équipement |
| `/top` | Classement mondial |
| `/help` | Aide complète |

### Commandes Divines (Admin)
| Commande | Description |
|----------|-------------|
| `/god <code>` | Accès administrateur |
| `/evenement <desc>` | Déclencher un événement |
| `/dbbackup` | Sauvegarder la base de données |

## Configuration Gemma 3

### Choisir la Version de Gemma 3

| Modèle | VRAM Requise | Qualité | Commande |
|--------|-------------|---------|----------|
| `gemma3:1b` | 2 GB | Basique | `ollama pull gemma3:1b` |
| `gemma3:4b` | 4-6 GB | **Recommandé** | `ollama pull gemma3:4b` |
| `gemma3:12b` | 10-12 GB | Excellente | `ollama pull gemma3:12b` |
| `gemma3:27b` | 20+ GB | Ultime | `ollama pull gemma3:27b` |

Modifier dans `.env` :
```env
OLLAMA_MODEL=gemma3:4b  # ou gemma3:12b, gemma3:27b
```

### Optimisation Ollama

Créer un fichier `Modelfile` pour personnaliser Gemma 3 :

```dockerfile
FROM gemma3:4b

PARAMETER temperature 0.85
PARAMETER top_p 0.9
PARAMETER top_k 40
PARAMETER num_ctx 16384

SYSTEM """Tu es le Maître du Jeu d'un RPG fantasy dark appelé ARISE. 
Tu dois répondre en JSON avec: narrative, actions, imagePrompt.
Style: Manhwa/Seinen, descriptions sensorielles précises, dialogues percutants."""
```

```bash
ollama create gheno-mj -f Modelfile
# Puis modifier OLLAMA_MODEL=gheno-mj dans .env
```

## Endpoints du Serveur

Le **World Intelligence Server** expose les endpoints suivants :

| Endpoint | Méthode | Description |
|----------|---------|-------------|
| `/` | GET | Informations du serveur |
| `/health` | GET | Vérification de santé (Ollama + Gemma 3) |
| `/v1/chat/completions` | POST | API MJ compatible OpenAI |

Exemple d'appel API :
```bash
curl -X POST http://localhost:3001/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{
    "model": "gemma3:4b",
    "messages": [
      {"role": "system", "content": "Tu es le MJ d\'ARISE."},
      {"role": "user", "content": "Le joueur attaque le gobelin."}
    ]
  }'
```

## Dépannage

### Ollama ne répond pas
```bash
# Vérifier qu'Ollama tourne
curl http://localhost:11434/api/tags

# Redémarrer Ollama
ollama serve
```

### Gemma 3 non trouvé
```bash
# Lister les modèles installés
ollama list

# Réinstaller Gemma 3
ollama pull gemma3:4b
```

### Erreur de connexion WhatsApp
```bash
# Supprimer la session et recommencer
rm -f gheno-city.sqlite
# ou supprimer les credentials de la DB
```

### Problèmes de mémoire
Si Gemma 3 est trop lent ou fait des erreurs :
1. Utilisez `gemma3:1b` ou `gemma3:4b` (plus léger)
2. Augmentez le timeout dans `.env`
3. Réduisez `num_ctx` dans `model-server.js`

### Fournisseurs AI (Fallback)
Si le serveur local Gemma 3 échoue, le bot essaie automatiquement :
1. World Server Local (Gemma 3)
2. Ollama Direct (Gemma 3)
3. Llamafile / 9Router / LM Studio
4. APIs Cloud (Puter, OpenRouter - si clés configurées)

## Structure du Projet

```
gheno-city-2-gemma3/
├── skype-bot.js              # Point d'entrée principal
├── model-server.js           # Serveur Gemma 3 (World Intelligence)
├── ai-handler.js             # Logique RPG et prompts MJ
├── ai-utils.js               # Providers AI (Gemma 3 en priorité)
├── command-handler.js        # Gestionnaire de commandes
├── database.js               # Modèles Sequelize
├── database-auth.js          # Auth Baileys
├── action-processor.js       # Traitement des actions AI
├── tutorial-handler.js       # Tutoriel de démarrage
├── message-handler.js        # Envoi de messages/images
├── game-state.js             # Cycle jour/nuit, météo
├── world-clock.js            # Horloge du monde RP
├── world-map.js              # Générateur de carte
├── profile-generator.js      # Cartes de profil
├── lore-generator.js         # Posters de lore
├── menu-generator.js         # Images de menu
├── shop-generator.js         # Images de boutique
├── paper-generator.js        # Documents manuscrits
├── equipment-visualizer.js   # Équipement visuel
├── class-visualizer.js       # Sélection de classe
├── start-image-generator.js  # Écran de démarrage
├── action-visual-generator.js # Visuels d'action
├── three-renderer.js         # Rendu 3D
├── package.json
├── .env
├── .env.example
└── README.md
```

## Licence

ISC

## Crédits

- **Projet original** : [Eoza-cell/GHENO-CITY-2](https://github.com/Eoza-cell/GHENO-CITY-2)
- **Gemma 3** : Google DeepMind
- **Ollama** : Ollama AI
- **Baileys** : @whiskeysockets
