const { createCanvas } = require('canvas');

async function generateLinkStartImage() {
    const width = 400;
    const height = 200;
    const canvas = createCanvas(width, height);
    const ctx = canvas.getContext('2d');

    const gradient = ctx.createLinearGradient(0, 0, 0, height);
    gradient.addColorStop(0, '#000000');
    gradient.addColorStop(0.5, '#1a0033');
    gradient.addColorStop(1, '#000000');
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, width, height);

    // Scan lines effect
    ctx.fillStyle = 'rgba(0, 255, 0, 0.05)';
    for (let i = 0; i < height; i += 3) {
        ctx.fillRect(0, i, width, 1);
    }

    ctx.fillStyle = '#00ff00';
    ctx.font = 'bold 32px monospace';
    ctx.textAlign = 'center';
    ctx.fillText('LINK START', width / 2, height / 2 - 10);

    ctx.fillStyle = '#00ff00';
    ctx.font = '14px monospace';
    ctx.fillText('Initialisation du système...', width / 2, height / 2 + 30);

    return canvas.toBuffer('image/png');
}

module.exports = { generateLinkStartImage };
