const { sendWithImage } = require('./message-handler');

async function checkLevelUp(player, sock) {
    const xpNeeded = player.level * 100;
    if (player.xp >= xpNeeded) {
        await player.increment('level', { by: 1 });
        await player.increment('skillPoints', { by: 3 });
        await player.increment('maxHealth', { by: 10 });
        await player.increment('maxMana', { by: 5 });
        await player.update({
            health: player.maxHealth + 10,
            mana: player.maxMana + 5,
            xp: player.xp - xpNeeded
        });
        await player.reload();

        if (sock) {
            await sock.sendMessage(player.whatsappId, {
                text: `🎉 *LEVEL UP !* Tu passes au niveau ${player.level} !\n\n✨ +3 SP | ❤️ +10 PV Max | 🔷 +5 PM Max`
            });
        }
        return true;
    }
    return false;
}

module.exports = { checkLevelUp };
