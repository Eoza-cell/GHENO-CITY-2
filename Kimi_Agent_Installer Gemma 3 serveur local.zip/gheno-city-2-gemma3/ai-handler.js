const { Player, Dungeon, Quest, PlayerQuest, Bank, Item, sequelize, Kingdom, Conflict, School, NPC, Skill, RPMessage, Monster, Entity, Club, Pact, House, Duel, TournamentParticipant } = require('./database');
const { sendWithImage, shouldNotifyPlayer } = require('./message-handler');
const { generatePaperImage } = require('./paper-generator');
const { generate3DVisual } = require('./three-renderer');
const { generateActionVisual } = require('./action-visual-generator');
const { generateProfileCard } = require('./profile-generator');
const { Op } = require('sequelize');
const { callAI } = require('./ai-utils');
const questUtils = require('./quest-utils');
const { processActions } = require('./action-processor');
const { checkLevelUp } = require('./level-utils');
const { isDay, getWeather } = require('./game-state');
const { getRPTime, getWorldHeader } = require('./world-clock');

async function handleFreeAction(sock, message, player, actionText) {
  const jid = message.key.remoteJid;

  try {
      await RPMessage.create({
          senderJid: player.whatsappId,
          senderName: player.name,
          content: actionText,
          location: player.location,
          subLocation: player.subLocation
      });
  } catch (e) {
      console.error("[DB] RPMessage log error:", e.message);
  }

  const writingMatch = actionText.match(/(?:écrit|écrire|rédige|rédiger|note|noter)(?:\s+sur\s+(?:du\s+)?papier|\s+une\s+note|\s+une\s+lettre|\s+l'examen)\s*:\s*([\s\S]+)/i);
  if (writingMatch) {
      const writtenText = writingMatch[1].trim();
      const isExam = actionText.toLowerCase().includes('examen');
      try {
          const paperBuffer = await generatePaperImage(writtenText, isExam ? "COPIE D'EXAMEN" : "NOTE MANUSCRITE");
          await sock.sendMessage(jid, {
              image: paperBuffer,
              caption: `📜 *Tu as fini d'écrire...*\n\n"${writtenText.substring(0, 100)}${writtenText.length > 100 ? '...' : ''}"`
          });
      } catch (err) {
          console.error("[Paper] Error:", err);
      }
  }

  const sceneFilter = { location: player.location, subLocation: player.subLocation };

  const nearbyPlayers = await Player.findAll({
    where: { location: player.location, subLocation: player.subLocation }
  });

  const otherActorsCount = nearbyPlayers.filter(p => p.whatsappId !== player.whatsappId).length;
  const isSolo = otherActorsCount === 0;
  const isTriggerWord = actionText.toLowerCase().trim() === 'next';

  const lastMJMessage = await RPMessage.findOne({
      where: { senderName: 'Arise MJ', ...sceneFilter },
      order: [['id', 'DESC']]
  });

  if (!isTriggerWord && !isSolo) {
      const recentPlayerMsgs = await RPMessage.count({
          where: { senderJid: player.whatsappId, id: { [Op.gt]: lastMJMessage ? lastMJMessage.id : 0 } }
      });

      let reminder = "";
      if (recentPlayerMsgs >= 3) {
          reminder = "\n\n💡 *Note:* Tu as envoyé plusieurs messages. N'oublie pas de taper `next` quand tu as fini.";
      }

      await sock.sendMessage(jid, {
          text: `⏳ *Action enregistrée.*${reminder}\nAttendez les autres joueurs pour \`next\`.`
      });
      return;
  }

  const kingdomMessageQuery = {
      location: player.location,
      senderName: { [Op.ne]: 'Arise MJ' }
  };
  if (lastMJMessage) kingdomMessageQuery.id = { [Op.gt]: lastMJMessage.id };

  const recentKingdomActions = await RPMessage.findAll({
      where: { ...kingdomMessageQuery, content: { [Op.notLike]: 'next' } },
      order: [['id', 'ASC']]
  });

  const playersCurrentlyHere = nearbyPlayers.map(p => p.name.toLowerCase());
  const recentActions = recentKingdomActions.filter(a => {
      if (a.subLocation === player.subLocation) return true;
      return playersCurrentlyHere.some(pName => a.content.toLowerCase().includes(pName));
  });

  const aggregatedActions = recentActions.length > 0
    ? recentActions.map(a => `${a.senderName}: ${a.content}`).join('\n')
    : "(Aucune action récente)";

  const lastActivity = new Date(player.lastActivity).getTime();
  const nowMs = Date.now();
  const realElapsedMs = nowMs - lastActivity;
  const rpElapsedHours = (realElapsedMs * 9) / (1000 * 60 * 60);

  if (rpElapsedHours > 0.05) {
      const hungerLoss = Math.floor(rpElapsedHours * 3);
      const sleepLoss = Math.floor(rpElapsedHours * 2);

      if (hungerLoss > 0) await player.decrement('hunger', { by: hungerLoss });
      if (sleepLoss > 0) await player.decrement('sleep', { by: sleepLoss });

      await player.reload();
      if (player.hunger < 0) await player.update({ hunger: 0 });
      if (player.sleep < 0) await player.update({ sleep: 0 });

      if (player.hunger === 0 && rpElapsedHours > 0.5) {
          await player.decrement('health', { by: 5 });
      }
      await player.update({ lastActivity: new Date() });
  }

  const playerState = `Nom:${player.name} | Sexe:${player.gender} | Age:${player.age} | Métier:${player.occupation} | Classe:${player.class}(${player.derivative}) | SP:${player.skillPoints} | Rang:${player.rank} | Niv:${player.level} | XP:${player.xp}/${player.level*100} | PV:${player.health}/${player.maxHealth} | PM:${player.mana}/${player.maxMana} | Hunger:${player.hunger}/100 | Sleep:${player.sleep}/100 | Col:${player.col} | Wanted:${player.wantedLevel}/10 | Prisonnier:${player.isPrisoner?'OUI':'NON'} | Lieu:${player.location} (${player.subLocation}) | STATS: FOR:${player.strength} AGI:${player.agility} INT:${player.intelligence} DEF:${player.defense} LUK:${player.luck}`;

  const inventory = player.inventory || [];
  const inventoryState = inventory.length > 0 ? "Inv: " + inventory.map(i => i.name).join(',') : "Inv: vide";

  const playerQuests = await player.getQuests();
  const activeQuests = playerQuests.filter(q => q.PlayerQuest.status === 'in_progress');
  const questState = activeQuests.length > 0 ? "Quêtes: " + activeQuests.map(q => `${q.title}(Progrès:${q.PlayerQuest.progress}%)`).join(',') : "Pas de quête";

  const history = await RPMessage.findAll({ where: sceneFilter, order: [['id', 'DESC']], limit: 75 });
  const historyState = history.length > 0 ? history.reverse().map(h => ({ sender: h.senderName, msg: h.content })) : [];

  const journal = await WorldJournal.findAll({ order: [['id', 'DESC']], limit: 40 });
  const journalState = journal.length > 0 ? journal.reverse().map(j => ({ cat: j.category, entry: j.entry })) : [];

  const allKingdoms = await Kingdom.findAll();
  const worldGeography = allKingdoms.map(k => `- ${k.name}: ${k.description}`).join('\n');

  let kingdom = allKingdoms.find(k => k.name === player.location);
  if (!kingdom) {
      kingdom = allKingdoms.find(k => k.description.toLowerCase().includes(player.location.toLowerCase()));
  }

  const npcs = await NPC.findAll({
    where: { [Op.and]: [ { [Op.or]: [ { location: { [Op.like]: `%${player.location}%` } }, { powerLevel: { [Op.gte]: 95 } } ] }, { role: { [Op.notLike]: '%Garde%' } } ] },
    order: sequelize.random(), limit: 5
  });
  const npcState = "PNJ: " + npcs.map(n => `${n.name}(Rôle:${n.role}, Force:${n.powerLevel})`).join(' | ');

  const monsters = await Monster.findAll({ where: { rank: player.rank }, limit: 2 });
  const monsterState = "Monstres: " + monsters.map(m => `${m.name}(PV:${m.health}, FOR:${m.strength})`).join(', ');

  const conflicts = await Conflict.findAll({ where: { status: 'active' } });
  const worldConflicts = conflicts.map(c => `[${c.title}] ${c.description}`).join(' | ');

  const rpTime = getRPTime();
  const cycleInfo = rpTime.isDay ? "JOUR" : "NUIT";
  const weather = getWeather();

  const triggerMiniEvent = Math.random() < 0.20;
  const miniEventContext = triggerMiniEvent ? "\n⚠️ **ÉVÉNEMENT IMPRÉVU**: Un événement aléatoire doit se produire !" : "";

  const systemPrompt = `Tu es le MJ d'un RP fantasy vivant et immersif. Style Manhwa/Seinen. Français cinématographique. CONCISION (Max 500 mots). JSON STRICT: {"pensee_mj":"...","narrative":"...","actions":[],"imagePrompt":""}. RÈGLES: Tu ne joues PAS les joueurs. Tu ne décris PAS leurs pensées. Précision chirurgicale. Stats déterminent les résultats. Étanchéité des histoires par joueur.`;

  const memoryJson = JSON.stringify({
    monde: { date: rpTime.formatted, cycle: cycleInfo, meteo: weather, royaume_actuel: kingdom?.name || player.location, lore_lieu: kingdom?.description || "" },
    joueur: { etat: playerState, inventaire: inventoryState, quetes: questState },
    env_social: { pnj: npcs.map(n => ({ name: n.name, role: n.role, power: n.powerLevel })), monstres: monsterState },
    memoire_long_terme: journalState,
    memoire_court_terme: historyState
  }, null, 2);

  const fullPrompt = `### CONTEXTE ###\n${memoryJson}\n\n### ACTIONS À TRAITER ###\n${aggregatedActions}${miniEventContext}\n\n### INSTRUCTIONS ###\nTraite l'action du joueur ${player.name}: "${actionText}". Réponds en JSON.`;

  try {
    let content = await callAI(systemPrompt, fullPrompt);
    if (!content) {
        content = JSON.stringify({ narrative: "🌀 *Le flux magique est instable...*" });
    }

    let aiResponse = { narrative: "", actions: [] };

    if (typeof content === 'object') {
        aiResponse = { ...aiResponse, ...content };
    } else {
        let start = content.indexOf('{');
        let end = content.lastIndexOf('}');

        if (start !== -1 && end !== -1 && end > start) {
            try {
                const parsed = JSON.parse(content.substring(start, end + 1));
                aiResponse = { ...aiResponse, ...parsed };
            } catch (e) {
                aiResponse.narrative = content.replace(/```[\s\S]*?```/g, '').replace(/\{[\s\S]*\}/g, '').trim();
            }
        }

        if (!aiResponse.narrative || aiResponse.narrative.length < 10) {
            aiResponse.narrative = content.replace(/```[\s\S]*?```/g, '').replace(/\{[\s\S]*\}/g, '').trim();
        }
    }

    if (!aiResponse.narrative || aiResponse.narrative.length < 3) {
        aiResponse.narrative = "L'action est en suspens...";
    }

    // Save bot response
    RPMessage.create({
        senderJid: 'bot', senderName: 'Arise MJ',
        content: aiResponse.narrative, location: player.location, subLocation: player.subLocation
    }).catch(e => console.error("[DB] MJ log error:", e.message));

    // Process actions
    const { questFeedback, playersToUpdate } = await processActions(sock, jid, player, aiResponse.actions || [], aiResponse, nearbyPlayers);

    if (questFeedback.length > 0) {
        aiResponse.narrative = `${aiResponse.narrative}\n\n${questFeedback.join('\n\n')}`;
    }

    aiResponse.narrative = `${getWorldHeader()}\n\n${aiResponse.narrative}`;

    await sendWithImage(sock, jid, aiResponse);

    // Auto-profile for updated players
    for (const pId of playersToUpdate) {
        try {
            const pToUpdate = await Player.findOne({ where: { whatsappId: pId } });
            if (pToUpdate && shouldNotifyPlayer(pToUpdate)) {
                await pToUpdate.reload();
                const profileBuffer = await generateProfileCard(pToUpdate);
                await sock.sendMessage(pId, {
                    image: profileBuffer,
                    caption: `--- 🆔 PROFIL MIS À JOUR : ${pToUpdate.name} ---`
                });
            }
        } catch (e) {
            console.error(`[AI] Profile update failed for ${pId}:`, e.message);
        }
    }

  } catch (error) {
    console.error('Erreur avec l\'IA:', error);
    await sock.sendMessage(jid, { text: "Erreur critique du MJ. L'action n'a pas pu être traitée." });
  }
}

module.exports = { handleFreeAction };
