const { createCanvas, loadImage, registerFont } = require('canvas');
const fs = require('fs');
const path = require('path');

async function generateLorePoster(title, content, type = 'LORE', imageUrl = null) {
    const width = 800;
    const height = 1000;
    const canvas = createCanvas(width, height);
    const ctx = canvas.getContext('2d');

    // Background
    const gradient = ctx.createLinearGradient(0, 0, 0, height);
    gradient.addColorStop(0, '#1a1a2e');
    gradient.addColorStop(1, '#16213e');
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, width, height);

    // Border
    ctx.strokeStyle = '#e94560';
    ctx.lineWidth = 4;
    ctx.strokeRect(20, 20, width - 40, height - 40);

    // Title
    ctx.fillStyle = '#e94560';
    ctx.font = 'bold 36px serif';
    ctx.textAlign = 'center';
    ctx.fillText(title.toUpperCase(), width / 2, 100);

    // Type badge
    ctx.fillStyle = '#0f3460';
    ctx.fillRect(width / 2 - 60, 120, 120, 30);
    ctx.fillStyle = '#e94560';
    ctx.font = 'bold 16px sans-serif';
    ctx.fillText(type, width / 2, 142);

    // Content
    ctx.fillStyle = '#eaeaea';
    ctx.font = '18px sans-serif';
    ctx.textAlign = 'left';

    const words = content.split(' ');
    let line = '';
    let y = 200;
    const lineHeight = 28;
    const maxWidth = width - 80;

    for (const word of words) {
        const testLine = line + word + ' ';
        const metrics = ctx.measureText(testLine);
        if (metrics.width > maxWidth && line.length > 0) {
            ctx.fillText(line, 40, y);
            line = word + ' ';
            y += lineHeight;
        } else {
            line = testLine;
        }
    }
    ctx.fillText(line, 40, y);

    // Footer
    ctx.fillStyle = '#666';
    ctx.font = 'italic 14px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('— Archives d\'Aetherys —', width / 2, height - 60);

    return canvas.toBuffer('image/png');
}

module.exports = { generateLorePoster };
