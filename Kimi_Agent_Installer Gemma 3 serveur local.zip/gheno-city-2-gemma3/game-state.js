let isCurrentlyDay = true;
let currentWeather = "clair";

const WEATHERS = ["clair", "nuageux", "pluvieux", "brumeux", "orageux"];

const DAY_DURATION = 15 * 60 * 1000;
const NIGHT_DURATION = 15 * 60 * 1000;

function updateDayNightCycle() {
  isCurrentlyDay = !isCurrentlyDay;

  if (Math.random() < 0.4) {
      currentWeather = WEATHERS[Math.floor(Math.random() * WEATHERS.length)];
  }

  setTimeout(updateDayNightCycle, isCurrentlyDay ? DAY_DURATION : NIGHT_DURATION);
}

function startDayNightCycle() {
    setTimeout(updateDayNightCycle, DAY_DURATION);
}

function isDay() {
  return isCurrentlyDay;
}

function getWeather() {
    return currentWeather;
}

function setWeather(newWeather) {
    currentWeather = newWeather;
}

module.exports = { startDayNightCycle, isDay, getWeather, setWeather };
