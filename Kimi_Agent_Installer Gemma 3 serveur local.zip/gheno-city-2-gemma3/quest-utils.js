const { Quest, Player } = require('./database');
const { Op } = require('sequelize');
const { checkLevelUp } = require('./level-utils');

async function findQuest(title) {
    if (!title) return null;
    return Quest.findOne({
        where: {
            [Op.or]: [
                { title: title },
                { title: { [Op.like]: `%${title}%` } }
            ]
        }
    });
}

async function getPlayerQuest(player, quest) {
    const rows = await player.getQuests({ where: { id: quest.id } });
    return rows.length > 0 ? rows[0].PlayerQuest : null;
}

async function startQuest(player, title) {
    const quest = await findQuest(title);
    if (!quest) return null;

    const existing = await getPlayerQuest(player, quest);
    if (existing && existing.status === 'in_progress') return null;
    if (existing && existing.status === 'completed') return null;

    if (existing) {
        await existing.update({ status: 'in_progress', progress: 0 });
    } else {
        await player.addQuest(quest, { through: { status: 'in_progress', progress: 0 } });
    }
    return `📜 *Nouvelle quête${quest.chain ? ` [${quest.chain} • étape ${quest.step}]` : ''}* : ${quest.title}\n${quest.objective || quest.description}`;
}

async function advanceQuest(player, title, progress, note) {
    const quest = await findQuest(title);
    if (!quest) return null;
    const pq = await getPlayerQuest(player, quest);
    if (!pq || pq.status === 'completed') return null;

    const newProgress = Math.max(0, Math.min(100, progress != null ? Number(progress) : pq.progress));

    if (typeof progress === 'string' && progress.startsWith('+')) {
        const inc = parseInt(progress.substring(1)) || 0;
        const meta = pq.metadata || {};
        meta.counter = (meta.counter || 0) + inc;
        await pq.update({ metadata: meta, progress: newProgress, notes: note || pq.notes });
    } else {
        await pq.update({ progress: newProgress, notes: note || pq.notes });
    }

    return `📈 *${quest.title}* — progression : ${newProgress}%`;
}

async function modifyQuest(player, title, branch, notes) {
    const quest = await findQuest(title);
    if (!quest) return null;
    const pq = await getPlayerQuest(player, quest);
    if (!pq) return null;

    await pq.update({
        branch: branch || pq.branch,
        notes: notes || pq.notes
    });
    return `🔀 *Le cours de la quête "${quest.title}" a changé !*${branch ? ` (${branch})` : ''}${notes ? `\n${notes}` : ''}`;
}

async function completeQuest(player, title, sock) {
    const quest = await findQuest(title);
    if (!quest) return null;
    const pq = await getPlayerQuest(player, quest);
    if (!pq || pq.status === 'completed') return null;

    await pq.update({ status: 'completed', progress: 100 });
    await pq.save();

    if (quest.reward_col) await player.increment('col', { by: quest.reward_col });
    if (quest.reward_xp) {
        await player.increment('xp', { by: quest.reward_xp });
        await checkLevelUp(player, sock);
    }
    await player.reload();

    let msg = `✅ *Quête terminée* : ${quest.title}\nRécompense : ${quest.reward_col} Col, ${quest.reward_xp} XP.`;

    if (quest.nextQuestTitle) {
        const nextLine = await startQuest(player, quest.nextQuestTitle);
        if (nextLine) msg += `\n\n➡️ *Suite de "${quest.chain}"*\n${nextLine}`;
    } else if (quest.chain) {
        msg += `\n\n🏆 Chaîne *"${quest.chain}"* terminée !`;
    }
    return msg;
}

async function startMultiplayerQuest(player, title) {
    const quest = await findQuest(title);
    if (!quest) return null;

    const startedSelf = await startQuest(player, title);

    const others = await Player.findAll({
        where: { location: player.location, whatsappId: { [Op.ne]: player.whatsappId } }
    });

    const notified = [];
    for (const other of others) {
        const line = await startQuest(other, title);
        if (line) notified.push({ player: other, line });
    }

    return {
        quest,
        narrative: startedSelf || `📜 *Quête coopérative* : ${quest.title}`,
        notified
    };
}

module.exports = {
    findQuest,
    startQuest,
    advanceQuest,
    modifyQuest,
    completeQuest,
    startMultiplayerQuest,
};
